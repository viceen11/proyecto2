<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<div class="row align-items-center justify-content-center">
    <div class="col-6">
        <div class="card text-bg-secondary">
            <div class="card-header text-center">
                Ingresar Propuesta
                <hr>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('estudiantes.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">                                                
                            <label for="nombre" class= "form-label">Nombre</label>
                            <input name="nombre" type="text" id="nombre" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="apellido" class="form-label">Apellido</label>
                            <input name="apellido" type="text" id="apellido" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="rut" class="form-label">Rut</label>
                            <input name="rut"type="text" id="rut" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input name="email" type="email" id="email" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label for="documento" class="form-label">Ingresar Documento</label>
                            <textarea name="documento" id="documento"  rows="4" class="form-control"></textarea>
                        </div>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-outline-light " type="submit">Enviar Propuesta</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</div>





<?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/home/index.blade.php ENDPATH**/ ?>