<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\HomeController;
use App\http\Controllers\EstudiantesController;
use App\http\Controllers\ProfesorController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//Route::get('/', function () {
 //   return view('welcome');
//});


Route::get('/',[HomeController::class, 'index'])->name('home.index');
Route::post('/', [EstudiantesController::class, 'store'])->name('estudiantes.store');
Route::get('/profesor',[ProfesorController::class,'index'])->name('profesor.index');